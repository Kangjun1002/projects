package com.kh.reMerge.feed.model.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class Tag {

	private String tagContent;
	private int refFno;
	
}
