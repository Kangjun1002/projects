package com.kh.reMerge.user.model.vo;

public class UserinfoAuthAPI {

	public void setId(String string) {
		// TODO Auto-generated method stub
		
	}

	public void setAuth(String string) {
		// TODO Auto-generated method stub
		
	}

}
