package com.kh.reMerge.feed.model.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class History {

	private int storyNo;
	private String userId;
}
